# CIA regex notes

- ``` Find (TITLE.+)(Biblio) Replace with <article>\1</article>\2``` 66 matches replaced
- ``` Find .+ Replace with <xml>\0</xml>``` One match replaced
- ``` Find Biblio.+[^</xml>] Replace with <citations>\0</citations>``` One match replaced
- ``` Put everything in citations onto a single line ```
- ``` Find ; Replace with ;\n``` 13 matches found
- ```Find ^[A-Z]+.+;$ Replace with <source>\0</source>``` 14 matches replacd 
- ```Find \s{7,} Replace with \n``` 8 matches replaced
- ``` Find .+ Replace with <line>\0</line>``` 49 matches replaced
- ``` Find [1-9]{4} Replace with <year>\0</year>``` 9 matches found